package com.app.staffmember;

public class Staff {
	private int id;
	private String name;
	private int salary;
	private int hours;
	private int charges;

	public Staff(String name, int id, int salary, int hours, int charges) {
		this.id = id;
		this.name = name;
		this.hours = hours;
		this.salary = salary;
		this.charges = charges;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getHours() {
		return hours;
	}

	public int getCharges() {
		return charges;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public void setCharges(int charges) {
		this.charges = charges;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String toString() {
		return "Staff Info => Id: " + id + ", Name: " + name + ", Salary: " + salary + ", Hours: " + hours + ", Charges: " + charges;
	}
}
