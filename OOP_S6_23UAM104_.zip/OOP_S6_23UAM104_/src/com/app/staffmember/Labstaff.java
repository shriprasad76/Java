package com.app.staffmember;

public class Labstaff {
	private int salary;

	public Labstaff(int salary) {
		super();
		this.salary = salary;
	}

	public int getSalary() {
		return salary;
	}

	public String toString() {
		return "Lab Staff => Salary: " + salary;
	}
}
