package com.app.staffmember;

public class Teachstaff {
	private int hours;
	private int charges;

	public Teachstaff(int hours, int charges) {
		super();
		this.hours = hours;
		this.charges = charges;
	}

	public int getHours() {
		return hours;
	}

	public int getCharges() {
		return charges;
	}

	public String toString() {
		return "Teaching Staff => Hours: " + hours + ", Charges per Hour: " + charges;
	}
}
