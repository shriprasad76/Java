package com.app.staffmember;
import java.util.Scanner;

public class Menu {

	public static void main(String[] args) {
		int max = 10;
		Staff[] staff = new Staff[max];
		int count = 0;
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("\n Staff Management Menu ");
			System.out.println("1. Add Teaching Staff");
			System.out.println("2. Add Lab Staff");
			System.out.println("3. Display All Teaching Staff");
			System.out.println("4. Display All Lab Staff");
			System.out.println("5. Find Teaching Staff by ID");
			System.out.println("6. Find Lab Staff by ID");
			System.out.println("7. Display Teaching Staff with Highest Hours");
			System.out.println("8. Display Lab Staff with Lowest Salary");
			System.out.println("9. Exit");
			System.out.print("Enter your choice: ");
			int ch = sc.nextInt();

			switch (ch) {
				case 1:
					if (count < max) {
						System.out.print("Enter name: ");
						String name = sc.next();
						System.out.print("Enter ID: ");
						int id = sc.nextInt();
						System.out.print("Enter number of hours: ");
						int hours = sc.nextInt();
						System.out.print("Enter charges per hour: ");
						int charges = sc.nextInt();
						staff[count++] = new Staff(name, id, 0, hours, charges);
						System.out.println("Teaching staff added.");
					} else {
						System.out.println("Staff limit complete.");
					}
					break;

				case 2:
					if (count < max) {
						System.out.print("Enter name: ");
						String name = sc.next();
						System.out.print("Enter ID: ");
						int id = sc.nextInt();
						System.out.print("Enter salary: ");
						int salary = sc.nextInt();
						staff[count++] = new Staff(name, id, salary, 0, 0);
						System.out.println("Lab staff added.");
					} else {
						System.out.println("Staff limit complete.");
					}
					break;

				case 3:
					System.out.println("Teaching Staff List:");
					for (int i = 0; i < count; i++) {
						if (staff[i].getSalary() == 0) {
							System.out.println(staff[i]);
						}
					}
					break;

				case 4:
					System.out.println("Lab Staff List:");
					for (int i = 0; i < count; i++) {
						if (staff[i].getHours()==0) {
							System.out.println(staff[i]);
						}
					}
					break;

				case 5:
					System.out.print("Enter ID to search Teaching Staff: ");
					int tid = sc.nextInt();
					boolean fT = false;
					for (int i = 0; i < count; i++) {
						if (staff[i].getId() == tid && staff[i].getSalary() == 0) {
							System.out.println("member Found: " + staff[i]);
							fT = true;
							break;
						}
					}
					if (!fT) {
						System.out.println("Teaching staff not found.");
					}
					break;

				case 6:
					System.out.print("Enter ID to search Lab Staff: ");
					int lid = sc.nextInt();
					boolean fL = false;
					for (int i = 0; i < count; i++) {
						if (staff[i].getId() == lid && staff[i].getHours() == 0) {
							System.out.println("Found: " + staff[i]);
							fL = true;
							break;
						}
					}
					if (!fL) {
						System.out.println("Lab staff not found.");
					}
					break;

				case 7:
					int maxHours = -1;
					Staff topTeaching = null;
					for (int i = 0; i < count; i++) {
						if (staff[i].getSalary() == 0 && staff[i].getHours() > maxHours) {
							maxHours = staff[i].getHours();
							topTeaching = staff[i];
						}
					}
					if (topTeaching != null) {
						System.out.println("Teaching staff with highest hours: " + topTeaching);
					} else {
						System.out.println("No teaching staff found.");
					}
					break;

				case 8:
					int minSalary = Integer.MAX_VALUE;
					Staff lowestLab = null;
					for (int i = 0; i < count; i++) {
						if (staff[i].getHours() == 0 && staff[i].getSalary() < minSalary) {
							minSalary = staff[i].getSalary();
							lowestLab = staff[i];
						}
					}
					if (lowestLab != null) {
						System.out.println("Lab staff with lowest salary: " + lowestLab);
					} else {
						System.out.println("No lab staff found.");
					}
					break;

				case 9:
					System.out.println("Exiting... Thank you!");
					sc.close();
					return;

				default:
					System.out.println("Invalid choice. Try again.");
			}
		}
	}
}
